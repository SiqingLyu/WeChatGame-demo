(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/Sun_Root_12/Sun6.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '0dfb4YTEQlIcq1hZIOncpDl', 'Sun6', __filename);
// scripts/Sun_Root_12/Sun6.js

"use strict";

var com = require("Common");

cc.Class({
    extends: cc.Component,

    properties: {
        is_shot: false,
        Arrow: cc.Node,
        Integral: 10,
        player: cc.Node
    },

    start: function start() {
        this.node.x = -650;
        this.node.y = -350;
        var interval = Math.random() + 4;
        var repeat = Math.floor(60 / interval);

        this.schedule(function () {
            var t1 = (Math.random() - 0.5) * 2; //产生 [-1，1) 间的随机数
            var t2 = (Math.random() - 0.5) * 2; //产生 [-1，1) 间的随机数
            var t_x = 255 + 55 * t1; // t_x --->  [-300 , 435)
            var t_y = 15 + 25 * t2; // t_y --->  [-200 , 190)
            this.node.x = t_x;
            this.node.y = t_y;
            console.log(t1, t2);
        }, interval, repeat);
    },
    update: function update(dt) {
        if (this.is_shot && this.node.y > -400) {
            this.node.y -= dt * 1000;
        } else if (this.node.y <= -400) {
            this.is_shot = false;
        }
    },
    onCollisionEnter: function onCollisionEnter(other, self) {
        if (this.node.x > -650) {
            var player = this.player.getComponent("playerInfo");
            player.score += this.Integral;
        }
        // console.log('现在正在有交集');
        // console.log(this.node.x, this.node.y);
        this.is_shot = true;
        var Arrow = this.Arrow.getComponent('Arrow');
        Arrow.fly = false;
        Arrow.node.x = -396;
        Arrow.node.y = -173;
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Sun6.js.map
        