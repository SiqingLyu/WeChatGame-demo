(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/Sprite/playerInfo.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '8dd81jhV/JMibmNih/Rll9m', 'playerInfo', __filename);
// scripts/playerInfo.js

"use strict";

var com = require("Common");
cc.Class({
    extends: cc.Component,

    properties: {
        score: 0,
        life: 100,
        weapon: 0,
        info: cc.Label
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        this.score = com.data;
        console.log("data:" + com.data);
    },
    start: function start() {},
    update: function update(dt) {
        console.log(this.score);
        this.info.string = "得分:" + this.score;
        com.data = Math.max(com.data, this.score);
        console.log(com.data);
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=playerInfo.js.map
        