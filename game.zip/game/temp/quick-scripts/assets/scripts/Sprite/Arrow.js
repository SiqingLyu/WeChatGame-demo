(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/Sprite/Arrow.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '4e0a6QUvg5L8JNnPJpIzIAW', 'Arrow', __filename);
// scripts/Sprite/Arrow.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        fly: false,
        v_x: 0,
        v_y: 0
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},
    update: function update(dt) {

        if (this.fly) {
            this.node.x += this.v_x * dt;

            this.v_y -= 500 * dt;

            this.node.y += this.v_y * dt;
            // console.log(this.v_y * dt);
            this.node.rotation = -Math.atan2(this.v_y, this.v_x) * 60 + 43;
        } else {
            this.v_x = 0;
            this.v_y = 0;
            this.node.rotation = 0;
        }
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Arrow.js.map
        