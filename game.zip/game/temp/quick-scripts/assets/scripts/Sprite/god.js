(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/Sprite/god.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '2158fZo5sRDPqjaEI8RdNFn', 'god', __filename);
// scripts/god.js

"use strict";

var bgm = require("music_ctrl");
cc.Class({
    extends: cc.Component,

    properties: {
        bgMusic: {
            default: null,
            type: cc.Button
        },
        gameAudio: {
            default: null,
            url: cc.AudioClip
        },
        gameOverAudio: {
            default: null,
            url: cc.AudioClip
        }
        // player: {
        //     default: null,
        //     type: cc.Node
        // }
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        cc.game.addPersistRootNode(this.node);
    },
    setEventCtrl: function setEventCtrl() {
        var mus = self.bgMusic.getComponent(bgm);

        cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: true,
            onTouchBegin: function onTouchBegin(touch, event) {
                var target = event.getCurrentTarget();

                var location = target.convertToNodeSpace(touch.getLocation());

                cc.log("当前点击：" + location);
                mus.setCp(touch.getLocation());
            }
        });
    },
    start: function start() {},
    update: function update(dt) {

        if (this.bgMusic.getComponent(bgm).isOpen) {
            cc.log('恢复播放');
            cc.audioEngine.resumeAll();
        } else {
            cc.log("暂停播放");
            cc.audioEngine.pauseAll();
        }
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=god.js.map
        