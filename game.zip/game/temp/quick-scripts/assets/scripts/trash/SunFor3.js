(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/trash/SunFor3.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '4c6b4fz0gtPLaCB9M0EuA+/', 'SunFor3', __filename);
// scripts/SunFor3.js

"use strict";

var com = require("Common");
cc.Class({
    extends: cc.Component,

    properties: {
        is_shot: false,
        Arrow: cc.Node,
        player: cc.Node
    },

    start: function start() {
        // if(this.is_shot) {
        //     console.log("123")
        // }
    },
    update: function update(dt) {
        if (this.is_shot && this.node.y > -400) {
            this.node.y -= dt * 1000;
        } else if (this.node.y <= -400) {
            this.is_shot = false;
        }
    },
    onCollisionEnter: function onCollisionEnter(other, self) {
        if (this.node.x > -650) {
            var player = this.player.getComponent("playerInfo");
            player.score += this.Integral;
        }
        // console.log('现在正在有交集');
        // console.log(this.node.x, this.node.y);
        this.is_shot = true;
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=SunFor3.js.map
        