(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/game_ctrl/Start.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '508e0E8QJpPKrTWpnMeCDo2', 'Start', __filename);
// scripts/Start.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        default: null,
        type: cc.Node,
        startBtn: cc.Button
    },

    start: function start() {
        this.startBtn.node.on("click", this.gotoWeapon, this);
        // cc.audioEngine.play("/music/BGM.mp3",loop);
    },
    gotoWeapon: function gotoWeapon() {
        cc.director.loadScene("weapon_choose");
    }
    // update (dt) {},

});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Start.js.map
        