(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/game_ctrl/draw.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'b0e63HQnxJNvrMsmLWl8z1+', 'draw', __filename);
// scripts/game_ctrl/draw.js

'use strict';

cc.Class({
    extends: cc.Component,

    properties: {},
    onLoad: function onLoad() {
        this.startPoint = cc.v2(0, 0);
        this.draw = this.node.getComponent(cc.Graphics);
    },


    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        this.node.on('touchstart', function (event) {
            var t_pos = event.getLocation();
            var pos = this.node.convertToNodeSpaceAR(t_pos);
            this.startPoint = pos;
        }, this);
        this.node.on('touchmove', function (event) {
            var t_pos = event.getLocation();
            var pos = this.node.convertToNodeSpaceAR(t_pos);

            this.draw.clear();
            this.draw.moveTo(this.startPoint.x + 440, this.startPoint.y + 320);
            // let dx =  pos.x - this.startPoint.x;
            // let dy =  pos.y - this.startPoint.y;
            // this.draw.lineTo(this.startPoint.x - dx +440,this.startPoint.y - dy +320);
            this.draw.lineTo(pos.x + 440, pos.y + 320);
            this.draw.stroke();
        }, this);

        this.node.on('touchend', function () {
            this.draw.clear();
        }, this);
    }
}

// update (dt) {},
);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=draw.js.map
        