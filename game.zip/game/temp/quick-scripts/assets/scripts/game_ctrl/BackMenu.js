(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/scripts/game_ctrl/BackMenu.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'b0c461LUVtNnZTHvCj8Fn4u', 'BackMenu', __filename);
// scripts/BackMenu.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        default: null,
        type: cc.Node,
        MenuBtn: cc.Button
    },

    start: function start() {
        this.MenuBtn.node.on("click", this.gotoMenu, this);
    },
    gotoMenu: function gotoMenu() {
        cc.director.loadScene("startScene");
    }
    // update (dt) {},

});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=BackMenu.js.map
        