"use strict";
cc._RF.push(module, '96affg0wl1Lq5n91jBAEgWx', 'weaponChoose');
// scripts/game_ctrl/weaponChoose.js

"use strict";

var com = require("Common");
cc.Class({
    extends: cc.Component,

    properties: {
        // default:null,
        type: cc.Node,
        player: cc.Node,
        firstBtn: cc.Button,
        secondBtn: cc.Button,
        thirdBtn: cc.Button
        // comfirmBtn:cc.Button
    },

    start: function start() {
        this.secondBtn.getComponent(cc.Button).interactable = false;
        this.thirdBtn.getComponent(cc.Button).interactable = false;
        var player = this.player.getComponent("playerInfo");
        player.score = com.data;
        cc.log(player.score);
        if (player.score > 300) {
            this.secondBtn.getComponent(cc.Button).interactable = true;
        }
        if (player.score > 600) {
            this.thirdBtn.getComponent(cc.Button).interactable = true;
        }
        this.firstBtn.node.on("click", this.chooseFirst, this);
        this.secondBtn.node.on("click", this.chooseSecond, this);
        this.thirdBtn.node.on("click", this.chooseThird, this);
        // this.comfirmBtn.node.on("click",this.gotoPlayScene,this);
    },
    chooseFirst: function chooseFirst() {
        cc.director.loadScene("play_scene");
    },
    chooseSecond: function chooseSecond() {
        cc.director.loadScene("play_scene_2");
    },
    chooseThird: function chooseThird() {
        cc.director.loadScene("play_scene_3");
    }
}
// gotoPlayScene(){
//     cc.director.loadScene("play_scene")
// }
// update (dt) {},
);

cc._RF.pop();