"use strict";
cc._RF.push(module, '74f8cyVoYRP35lTnDlnJ1Ws', 'Sun');
// scripts/Sun.js

"use strict";

var com = require("Common");
cc.Class({
    extends: cc.Component,

    properties: {
        is_shot: false,
        Arrow: cc.Node,
        player: cc.Node
    },

    start: function start() {

        // if (this.is_shot) {
        //     console.log("123");
        // }
    },
    update: function update(dt) {
        if (this.is_shot && this.node.y > -400) {
            this.node.y -= dt * 1000;
        } else if (this.node.y <= -400) {
            this.is_shot = false;
        }
    },
    onCollisionEnter: function onCollisionEnter(other, self) {
        var player = this.player.getComponent("playerInfo");
        player.score += 1;
        com.data = player.score;
        // console.log('得分' + player.score);
        // console.log('现在正在有交集');
        // console.log(this.node.x, this.node.y);
        this.is_shot = true;
        var Arrow = this.Arrow.getComponent('Arrow');
        Arrow.fly = false;
        Arrow.node.x = -396;
        Arrow.node.y = -173;
    }
});

cc._RF.pop();