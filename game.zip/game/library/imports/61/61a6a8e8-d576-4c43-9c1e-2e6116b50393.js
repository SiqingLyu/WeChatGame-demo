"use strict";
cc._RF.push(module, '61a6ajo1XZMQ5weLmEWtQOT', 'Common');
// scripts/Common.js

"use strict";

module.exports = {

    data: 0

};

cc._RF.pop();