"use strict";
cc._RF.push(module, 'cb5d0mbYjxB+q9zET3BONTC', 'invisible');
// scripts/invisible.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        yesPic: cc.Sprite
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {
        this.yesPic.setVisible(false);
    }
}

// update (dt) {},
);

cc._RF.pop();