"use strict";
cc._RF.push(module, '8dd81jhV/JMibmNih/Rll9m', 'playerInfo');
// scripts/playerInfo.js

"use strict";

var com = require("Common");
cc.Class({
    extends: cc.Component,

    properties: {
        score: 0,
        life: 100,
        weapon: 0,
        info: cc.Label
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        this.score = com.data;
        console.log("data:" + com.data);
    },
    start: function start() {},
    update: function update(dt) {
        console.log(this.score);
        this.info.string = "得分:" + this.score;
        com.data = Math.max(com.data, this.score);
        console.log(com.data);
    }
});

cc._RF.pop();