"use strict";
cc._RF.push(module, 'b0c461LUVtNnZTHvCj8Fn4u', 'BackMenu');
// scripts/BackMenu.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        default: null,
        type: cc.Node,
        MenuBtn: cc.Button
    },

    start: function start() {
        this.MenuBtn.node.on("click", this.gotoMenu, this);
    },
    gotoMenu: function gotoMenu() {
        cc.director.loadScene("startScene");
    }
    // update (dt) {},

});

cc._RF.pop();