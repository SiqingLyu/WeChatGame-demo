"use strict";
cc._RF.push(module, '91dc8Nsv3FJlYNXb0B5w5UE', 'music_ctrl');
// scripts/music_ctrl.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        isOpen: true,
        gameAudio: {
            default: null,
            url: cc.AudioClip
        }
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        this.isOpen = true;
        cc.audioEngine.play(this.gameAudio, true);
    },

    checkMuis: function checkMuis() {
        return isOpen;
    },
    setCp: function setCp(pos) {
        var rec = cc.rectContainsPoint(this.node.getBoundingBoxToWorld(), pos);
        if (rec) {
            if (this.isOpen) {
                cc.audioEngine.pause();
                // cc.log('已暂停');
                this.isOpen = false;
            } else {
                cc.audioEngine.resume();
                // cc.log('已回复');
                this, isOpen = true;
            }
        }
    },

    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();