"use strict";
cc._RF.push(module, '508e0E8QJpPKrTWpnMeCDo2', 'Start');
// scripts/Start.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        default: null,
        type: cc.Node,
        startBtn: cc.Button
    },

    start: function start() {
        this.startBtn.node.on("click", this.gotoWeapon, this);
        // cc.audioEngine.play("/music/BGM.mp3",loop);
    },
    gotoWeapon: function gotoWeapon() {
        cc.director.loadScene("weapon_choose");
    }
    // update (dt) {},

});

cc._RF.pop();