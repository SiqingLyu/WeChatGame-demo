var com = require("Common")

cc.Class({
    extends: cc.Component,

    properties: {
        is_shot : false,
        Arrow : cc.Node,
        Integral : 10,
        player:cc.Node
    },

    start () {
        this.node.x = -650
        this.node.y = -350
        var interval = Math.random() + 4
        var repeat = Math.floor(60 / interval)

        this.schedule(function () {
            var t1 = (Math.random() - 0.5)* 2   //产生 [-1，1) 间的随机数
            var t2 = (Math.random() - 0.5)* 2   //产生 [-1，1) 间的随机数
            var t_x = 255 + 55 * t1         // t_x --->  [-300 , 435)
            var t_y = 15 + 25 * t2             // t_y --->  [-200 , 190)
            this.node.x = t_x
            this.node.y = t_y
            console.log(t1, t2)
        }, interval, repeat)
    },

    update (dt) {
        if (this.is_shot && this.node.y > -400) {
            this.node.y -= dt*1000;
        }
        else if (this.node.y <= -400){
            this.is_shot = false
        }
    },

    onCollisionEnter(other, self) {
        if(this.node.x>-650){
            let player = this.player.getComponent("playerInfo");
            player.score += this.Integral;
        }
        // console.log('现在正在有交集');
        // console.log(this.node.x, this.node.y);
        this.is_shot = true;
        let Arrow = this.Arrow.getComponent('Arrow');
        Arrow.fly = false;
        Arrow.node.x = -396;
        Arrow.node.y = -173;
    },
});