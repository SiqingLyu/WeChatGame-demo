

cc.Class({
    extends: cc.Component,

    properties: {
     yesPic : cc.Sprite,
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {
        this.yesPic.setVisible(false);

    },

    // update (dt) {},
});
