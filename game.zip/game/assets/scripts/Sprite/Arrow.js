

cc.Class({
    extends: cc.Component,

    properties: {
        fly : false,
        v_x : 0,
        v_y : 0,
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {

    },

    update (dt) {


        if(this.fly){
            this.node.x +=this.v_x * dt;

            this.v_y -= 500 * dt;

            this.node.y += this.v_y *dt;
            // console.log(this.v_y * dt);
            this.node.rotation = -Math.atan2(this.v_y,this.v_x)*60+43;
        }
        else{
            this.v_x = 0 ;
            this.v_y = 0;
            this.node.rotation = 0;
        }
    },
});
