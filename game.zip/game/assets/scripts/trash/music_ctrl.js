

cc.Class({
    extends: cc.Component,

    properties: {
        isOpen : true,
        gameAudio:{
            default : null,
            url: cc.AudioClip
        }
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad () {
        this.isOpen = true;
        cc.audioEngine.play(this.gameAudio,true);
    },
    checkMuis: function(){
        return isOpen;
    },
    setCp: function(pos){
        var rec = cc.rectContainsPoint(this.node.getBoundingBoxToWorld(),pos);
        if(rec){
            if(this.isOpen){
                cc.audioEngine.pause();
                // cc.log('已暂停');
                this.isOpen = false;
            }
            else{
                cc.audioEngine.resume();
                // cc.log('已回复');
                this,isOpen = true;
            }
        }
    },

    start () {

    },

    // update (dt) {},
});
