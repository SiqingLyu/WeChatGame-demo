
cc.Class({
    extends: cc.Component,

    properties: {
        default:null,
        type:cc.Node,
        MenuBtn:cc.Button
    },

  
    start () {
        this.MenuBtn.node.on("click",this.gotoMenu,this)
    },

    gotoMenu(){
        cc.director.loadScene("startScene")
    }
    // update (dt) {},
});
