
cc.Class({
    extends: cc.Component,

    properties: {
        hand : cc.Node,
        Arrow : cc.Node,

        AudioBtn:{
            default : null,
            url : cc.AudioClip,
        }
    },
    onLoad(){
      this.startPoint = cc.v2(0,0);
      this.hudu = 0;
      this.lidu = 0;
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {
        let Arrow = this.Arrow.getComponent('Arrow');
        Arrow.node.rotation = 0;
        Arrow.v_x = 0;
        Arrow.v_y = 0;
        this.node.on('touchstart',function (event) {
            Arrow.fly =false;
            let t_pos = event.getLocation();
            let pos = this.node.convertToNodeSpaceAR(t_pos);
            this.startPoint = pos;
        },this);
        this.node.on('touchmove',function (event) {
            let t_pos = event.getLocation();
            let pos = this.node.convertToNodeSpaceAR(t_pos);
            let d_x = this.startPoint.x - pos.x;
            let d_y = this.startPoint.y - pos.y;
            this.hudu = Math.atan2(d_y,d_x);
            this.lidu = Math.pow(d_x*d_x+d_y*d_y,0.5);

            this.hand.rotation = -45;
            this.Arrow.x = -396 - 30;
            this.Arrow.y = -173 - 14;
        },this);

        this.node.on('touchend',function () {
            this.hand.rotation = 0;
            this.Arrow.x = -396;
            this.Arrow.y = -173;
            this.ArrowFly(this.lidu * 5 , this.hudu);
            // cc.audioEngine.play(this.AudioBtn,false,1);
        },this);
    },

    ArrowFly(lidu,hudu){
        let Arrow = this.Arrow.getComponent('Arrow');
        Arrow.fly = false;
        Arrow.v_x = lidu * Math.cos(hudu);
        Arrow.v_y = lidu * Math.sin(hudu);

        // console.log(hudu);
        if(Arrow.v_x > 250 & Arrow.v_y > 0 | Arrow.v_x >0 & Arrow.v_y> 255 | ((hudu-1.8) < 0.1 & Arrow.v_y>0) ){
                Arrow.fly = true;
        }

    }
    // update (dt) {},
});
