
cc.Class({
    extends: cc.Component,

    properties: {
        default:null,
        type:cc.Node,
        startBtn:cc.Button
    },

    start () {
        this.startBtn.node.on("click",this.gotoWeapon,this)
         // cc.audioEngine.play("/music/BGM.mp3",loop);
    },
    gotoWeapon(){
        cc.director.loadScene("weapon_choose")
    }
    // update (dt) {},
});
